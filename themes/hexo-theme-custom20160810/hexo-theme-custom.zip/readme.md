hexo-theme-custom
---
custom是一个hexo主题，目前在[unofficial's blog](www.unofficial.cn)使用，会不断按照自己的想法优化，也许不那么美，但有一个向往美的心，有更好的想法可以与我一起交流。

#### 如何开始？
方法一：  
```
git clone https://github.com/cangku/hexo-theme-custom.git
```
方法二：  
```
npm install hexo-theme-custom
```

#### 更新内容
1. 博客第一个版本上线  
   只是做了简单的样式排版，没有duang一样的特效，简去繁是中心，后续慢慢优化
2. 待更新
