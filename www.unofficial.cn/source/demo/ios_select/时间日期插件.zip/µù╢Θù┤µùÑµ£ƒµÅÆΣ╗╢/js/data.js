var uiCont = $(".ui-cont");
var pickTrigger = $(".pick-trigger");
var uiMask = $(".ui-mask");
//调出选择框
pickTrigger.click(function() {
	uiCont.addClass("active");
	uiMask.addClass("active");
});

//获得item(li)高度 
var itemHeight = $(".ui-roller li")[0].offsetHeight;

//监听touchstart事件
$(".ui-body ul").bind("touchstart", function(e) {

	var thisObj = $(this);
	var thisId = $(this).attr("id");
	var ui = $("#" + thisId + "");
	var uiY = document.getElementById(thisId).style.transform;
	var mdY = null;
	var moveY = null;
	var upY = null;

	//获取translateY的值
	uiY = parseInt(uiY.match(/-?\d{1,4}/)[0]);

	//获得当前选项卡中有几个item(li)
	var itemNum = thisObj.find("li").length;
	//uiY最大正值
	var maxUiY = itemHeight * 2;
	//uiY最大负值
	var minUiY = -(itemNum - 3) * itemHeight;

	var mdY = e.touches[0].clientY;
	//监听touchmove
	$(document).bind("touchmove", function(e) {
		moveY = (e.touches[0].clientY - mdY) * 1.5;
		ui.css("transform", "translateY(" + (uiY + moveY) + "px)");
		e.preventDefault();
	});
	//监听touchend
	$(document).bind("touchend", function(e) {
		if(moveY % itemHeight > 0) {
			moveY = moveY + (itemHeight - moveY % itemHeight);
		} else if(moveY % itemHeight < 0) {
			moveY = moveY + (-itemHeight - moveY % itemHeight);
		}

		uiY = uiY + moveY;
		if(uiY > maxUiY) {
			uiY = maxUiY;
		} else if(uiY < minUiY) {
			uiY = minUiY;
		}

		ui.css("transform", "translateY(" + uiY + "px)");

		changNowItem(thisId, uiY); //改变当前选中效果
		$(document).unbind("touchend");
		$(document).unbind("touchmove");
	})
})

function changNowItem(typeId, uiY) {
	$("#" + typeId + " li").removeClass("active");
	var num = 2 - uiY / itemHeight;
	$("#" + typeId).find("li").eq(num).addClass("active");
}

//初始化
function DataPickerInit(year, month, day) {
	initItem("year", year);
	initItem("month", month);
	initItem("day", day);
}
//具体项目初始化
function initItem(typeId, value) {
	var typeDocument = $("#" + typeId + " li[data-value='" + value + "']");
	typeDocument.addClass("active");
	var uiIndex = typeDocument.index() + 1;
	var uiY = (3 - uiIndex) * itemHeight;;

	$("#" + typeId).css("transform", "translateY(" + uiY + "px)")
}

//确定选择日期
$(".confirm").click(function(){
	var year = $("#year li.active").attr("data-value");
	var month = $("#month li.active").attr("data-value");
	var day = $("#day li.active").attr("data-value");
	
	var confirmData = year+"-"+month+"-"+day;
	
	$(".pick-trigger").val(confirmData);
	uiCont.removeClass("active");
	uiMask.removeClass("active");
})
//取消选择日期
$(".cancel,.ui-mask").click(function(){
	uiCont.removeClass("active");
	uiMask.removeClass("active");
});
