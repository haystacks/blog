DROP TABLE IF EXISTS `ims_unofficial_music`;
DROP TABLE IF EXISTS `ims_unofficial_music_detail`;
