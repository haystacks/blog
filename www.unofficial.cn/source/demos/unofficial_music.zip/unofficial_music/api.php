<?php
    define('IN_IA', true);
    require '../addons/unofficial_music/site.php';
    $site = new Unofficial_musicModuleSite();
    $site -> doWebNo();
?>
